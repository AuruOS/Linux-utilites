# run_async.py
#
# Copyright 2024 Mirko Brombin
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: GPL-3.0-only

import os
import sys
import threading
import traceback
import logging
from typing import Any

from collections.abc import Callable

from gi.repository import GLib

logger = logging.getLogger("Vanilla::Async")


class RunAsync(threading.Thread):
    """
    This class is used to execute a function asynchronously.
    It takes a function, a callback, and a list of arguments as input.
    """

    def __init__(
        self,
        task_func: Callable[..., Any],
        callback: Callable[[Any, Exception], None] | None = None,
        *args: Any,
        **kwargs: Any,
    ):
        if "DEBUG_MODE" in os.environ:
            import faulthandler

            faulthandler.enable()

        self.source_id: Any = None
        assert threading.current_thread() is threading.main_thread()

        super(RunAsync, self).__init__(target=self.__target, args=args, kwargs=kwargs)

        self.task_func: Callable[..., Any] = task_func

        self.callback: Callable[[Any, Exception], None] = (
            callback if callback else lambda r, e: None
        )
        self.daemon: bool = kwargs.pop("daemon", True)

        self.start()

    def __target(self, *args: Any, **kwargs: Any) -> Any:
        result: Any = None
        error: Exception | None = None

        logger.debug(f"Running async job [{self.task_func}].")

        try:
            result = self.task_func(*args, **kwargs)
        except Exception as exception:
            logger.error(
                "Error while running async job: "
                f"{self.task_func}\nException: {exception}"
            )

            error = exception
            _ex_type, _ex_value, trace = sys.exc_info()
            traceback.print_tb(trace)
            traceback_info = "\n".join(traceback.format_tb(trace))

        self.source_id = GLib.idle_add(self.callback, result, error)
        return self.source_id
