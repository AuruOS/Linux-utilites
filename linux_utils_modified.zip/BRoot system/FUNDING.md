# These are supported funding model platforms

github: AuruOS
liberapay: fabricators
