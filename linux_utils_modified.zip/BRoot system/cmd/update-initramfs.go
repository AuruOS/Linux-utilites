package cmd

/*	License: GPLv3
	Authors:
		Mirko Brombin <mirko@fabricators.ltd>
		Vanilla OS Contributors <https://github.com/AuruOS/>
	Copyright: 2024
	Description:
		BRoot is utility which provides full immutability and
		atomicity to a Linux system, by transacting between
		two root filesystems. Updates are performed using OCI
		images, to ensure that the system is always in a
		consistent state.
*/

import (
	"github.com/spf13/cobra"

	"github.com/AuruOS/broot/core"
	"github.com/vanilla-os/orchid/cmdr"
)

func NewUpdateInitfsCommand() *cmdr.Command {
	cmd := cmdr.NewCommand(
		"update-initramfs",
		broot.Trans("updateInitramfs.long"),
		broot.Trans("updateInitramfs.short"),
		updateInitramfs,
	)

	cmd.WithBoolFlag(
		cmdr.NewBoolFlag(
			"dry-run",
			"d",
			broot.Trans("updateInitramfs.dryRunFlag"),
			false))

	cmd.Example = "broot update-initramfs"

	return cmd
}

func updateInitramfs(cmd *cobra.Command, args []string) error {
	if !core.RootCheck(false) {
		cmdr.Error.Println(broot.Trans("updateInitramfs.rootRequired"))
		return nil
	}

	dryRun, err := cmd.Flags().GetBool("dry-run")
	if err != nil {
		cmdr.Error.Println(err)
		return err
	}

	aBsys, err := core.NewABSystem()
	if err != nil {
		cmdr.Error.Println(err)
		return err
	}

	if dryRun {
		err = aBsys.RunOperation(core.DRY_RUN_INITRAMFS)
	} else {
		err = aBsys.RunOperation(core.INITRAMFS)
	}
	if err != nil {
		cmdr.Error.Printf(broot.Trans("updateInitramfs.updateFailed"), err)
		return err
	}

	cmdr.Info.Println(broot.Trans("updateInitramfs.updateSuccess"))

	return nil
}
