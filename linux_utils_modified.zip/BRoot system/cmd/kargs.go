package cmd

/*	License: GPLv3
	Authors:
		Mirko Brombin <mirko@fabricators.ltd>
		Vanilla OS Contributors <https://github.com/AuruOS/>
	Copyright: 2024
	Description:
		BRoot is utility which provides full immutability and
		atomicity to a Linux system, by transacting between
		two root filesystems. Updates are performed using OCI
		images, to ensure that the system is always in a
		consistent state.
*/

import (
	"errors"

	"github.com/spf13/cobra"

	"github.com/AuruOS/broot/core"
	"github.com/vanilla-os/orchid/cmdr"
)

var validKargsArgs = []string{"edit", "show"}

func NewKargsCommand() *cmdr.Command {
	cmd := cmdr.NewCommand(
		"kargs edit|show",
		broot.Trans("kargs.long"),
		broot.Trans("kargs.short"),
		kargs,
	)

	cmd.Args = cobra.MatchAll(cobra.ExactArgs(1), cobra.OnlyValidArgs)
	cmd.ValidArgs = validKargsArgs
	cmd.Example = "broot kargs edit"

	return cmd
}

func kargs(cmd *cobra.Command, args []string) error {
	if !core.RootCheck(false) {
		cmdr.Error.Println(broot.Trans("kargs.rootRequired"))
		return nil
	}

	switch args[0] {
	case "edit":
		changed, err := core.KargsEdit()
		if err != nil {
			cmdr.Error.Println(err)
			return err
		}

		if !changed {
			cmdr.Info.Println(broot.Trans("kargs.notChanged"))
			return nil
		}

		aBsys, err := core.NewABSystem()
		if err != nil {
			cmdr.Error.Println(err)
			return err
		}
		err = aBsys.RunOperation(core.APPLY)
		if err != nil {
			cmdr.Error.Println(broot.Trans("pkg.applyFailed"))
			return err
		}
	case "show":
		kargsStr, err := core.KargsRead()
		if err != nil {
			cmdr.Error.Println(err)
			return err
		}
		cmdr.Info.Println(kargsStr)
	default:
		return errors.New(broot.Trans("kargs.unknownCommand", args[0]))
	}

	return nil
}
