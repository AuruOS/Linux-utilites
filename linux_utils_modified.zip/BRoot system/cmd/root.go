package cmd

/*	License: GPLv3
	Authors:
		Mirko Brombin <mirko@fabricators.ltd>
		Vanilla OS Contributors <https://github.com/AuruOS/>
	Copyright: 2024
	Description:
		BRoot is utility which provides full immutability and
		atomicity to a Linux system, by transacting between
		two root filesystems. Updates are performed using OCI
		images, to ensure that the system is always in a
		consistent state.
*/

import (
	"embed"

	"github.com/vanilla-os/orchid/cmdr"
)

var broot *cmdr.App

const (
	verboseFlag string = "verbose"
)

func New(version string, fs embed.FS) *cmdr.App {
	broot = cmdr.NewApp("broot", version, fs)
	return broot
}

func NewRootCommand(version string) *cmdr.Command {
	root := cmdr.NewCommand(
		broot.Trans("broot.use"),
		broot.Trans("broot.long"),
		broot.Trans("broot.short"),
		nil).
		WithPersistentBoolFlag(
			cmdr.NewBoolFlag(
				verboseFlag,
				"V",
				broot.Trans("broot.verboseFlag"),
				false))
	root.Version = version

	return root
}
