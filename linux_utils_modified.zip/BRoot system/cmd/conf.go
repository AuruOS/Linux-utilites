package cmd

/*	License: GPLv3
	Authors:
		Mirko Brombin <mirko@fabricators.ltd>
		Vanilla OS Contributors <https://github.com/AuruOS/>
	Copyright: 2024
	Description:
		BRoot is utility which provides full immutability and
		atomicity to a Linux system, by transacting between
		two root filesystems. Updates are performed using OCI
		images, to ensure that the system is always in a
		consistent state.
*/

import (
	"github.com/spf13/cobra"

	"github.com/AuruOS/broot/core"
	"github.com/vanilla-os/orchid/cmdr"
)

func NewConfCommand() *cmdr.Command {
	cmd := cmdr.NewCommand(
		"config-editor",
		broot.Trans("cnf.long"),
		broot.Trans("cnf.short"),
		cnf,
	)

	return cmd
}

func cnf(cmd *cobra.Command, args []string) error {
	if !core.RootCheck(false) {
		cmdr.Error.Println(broot.Trans("cnf.rootRequired"))
		return nil
	}

	result, err := core.ConfEdit()
	switch result {
	case core.CONF_CHANGED:
		cmdr.Info.Println(broot.Trans("cnf.changed"))
	case core.CONF_UNCHANGED:
		cmdr.Info.Println(broot.Trans("cnf.unchanged"))
	case core.CONF_FAILED:
		cmdr.Error.Println(broot.Trans("cnf.failed", err))
	}

	return nil
}
