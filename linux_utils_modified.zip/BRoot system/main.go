package main

/*	License: GPLv3
	Authors:
		Mirko Brombin <mirko@fabricators.ltd>
		Vanilla OS Contributors <https://github.com/AuruOS/>
	Copyright: 2024
	Description:
		BRoot is utility which provides full immutability and
		atomicity to a Linux system, by transacting between
		two root filesystems. Updates are performed using OCI
		images, to ensure that the system is always in a
		consistent state.
*/

import (
	"embed"

	"github.com/containers/storage/pkg/reexec"
	"github.com/AuruOS/broot/cmd"
	"github.com/AuruOS/broot/settings"
	"github.com/vanilla-os/orchid/cmdr"
)

var Version = "development"

//go:embed locales/*.yml
var fs embed.FS
var broot *cmdr.App

func main() {
	if reexec.Init() {
		return
	}

	broot = cmd.New(Version, fs)

	// root command
	root := cmd.NewRootCommand(Version)
	broot.CreateRootCommand(root, broot.Trans("broot.msg.help"), broot.Trans("broot.msg.version"))

	msgs := cmdr.UsageStrings{
		Usage:                broot.Trans("broot.msg.usage"),
		Aliases:              broot.Trans("broot.msg.aliases"),
		Examples:             broot.Trans("broot.msg.examples"),
		AvailableCommands:    broot.Trans("broot.msg.availableCommands"),
		AdditionalCommands:   broot.Trans("broot.msg.additionalCommands"),
		Flags:                broot.Trans("broot.msg.flags"),
		GlobalFlags:          broot.Trans("broot.msg.globalFlags"),
		AdditionalHelpTopics: broot.Trans("broot.msg.additionalHelpTopics"),
		MoreInfo:             broot.Trans("broot.msg.moreInfo"),
	}
	broot.SetUsageStrings(msgs)

	upgrade := cmd.NewUpgradeCommand()
	root.AddCommand(upgrade)

	kargs := cmd.NewKargsCommand()
	root.AddCommand(kargs)

	// we only add the pkg command if the BRoot configuration
	// has the IPkgMng enabled in any way (1 or 2)
	if settings.Cnf.IPkgMngStatus > 0 {
		pkg := cmd.NewPkgCommand()
		root.AddCommand(pkg)
	}

	rollback := cmd.NewRollbackCommand()
	root.AddCommand(rollback)

	status := cmd.NewStatusCommand()
	root.AddCommand(status)

	updateInitramfs := cmd.NewUpdateInitfsCommand()
	root.AddCommand(updateInitramfs)

	cnf := cmd.NewConfCommand()
	root.AddCommand(cnf)

	unlockVar := cmd.NewUnlockVarCommand()
	root.AddCommand(unlockVar)

	mntSys := cmd.NewMountSysCommand()
	root.AddCommand(mntSys)

	// run the app
	err := broot.Run()
	if err != nil {
		cmdr.Error.Println(err)
	}
}
